import random
import time

def generador_numero_aleatorio():
    return random.randint(0, 2)

def shuffling(choices):
    keys = list(choices.keys())
    values = list(choices.values())
    random.shuffle(keys)
    time.sleep(0.1)
    random.shuffle(values)
    dict_shuffle = {}
    for k, v in zip(keys, values):
        dict_shuffle[k] = v
    return dict_shuffle
