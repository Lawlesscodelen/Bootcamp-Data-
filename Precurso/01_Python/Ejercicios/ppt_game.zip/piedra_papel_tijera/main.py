from sys import argv
import config as c
from juego import logic

if __name__ == '__main__':

    INPUT_HUMANO = argv[1].capitalize()

    try:
        if INPUT_HUMANO in ['Ti', list(c.CHOICES.values())[2]]:
            INPUT_HUMANO = list(c.CHOICES.values())[2]
        elif INPUT_HUMANO in ['Pi', list(c.CHOICES.values())[0]]:
            INPUT_HUMANO = list(c.CHOICES.values())[0]
        elif INPUT_HUMANO in ['Pa', list(c.CHOICES.values())[1]]:
            INPUT_HUMANO = list(c.CHOICES.values())[1]
        else:
            raise ValueError(f'Los argumentos válidos son {c.CHOICES.values()} o [Pi, Pa, Ti]')

        logic(INPUT_HUMANO)

    except Exception as e:

        print('Algo no funcionó en el juego')
        print(e)
