import aleatorio
import config as c

def logic(arg):

    dict_choices = aleatorio.shuffling(c.CHOICES)

    random_number = aleatorio.generador_numero_aleatorio()

    cc = dict_choices.get(random_number)

    piedra = list(c.CHOICES.values())[0]
    papel = list(c.CHOICES.values())[1]
    tijera = list(c.CHOICES.values())[2]

    if arg == cc:
        print('Empate ¿jugamos otra?')
    elif (arg == tijera and cc == papel) or (arg == papel and cc == piedra) or (arg == piedra and cc == tijera):
        print('¡Has ganado! ¿jugamos otra?')
    else:
        print('¡Has perdido! ¿jugamos otra?')
